﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Neremnem
{
    public enum ERange
    {
        Bash = 0
        , Whirlwind = 1
        , Jump = 2
    }

}

