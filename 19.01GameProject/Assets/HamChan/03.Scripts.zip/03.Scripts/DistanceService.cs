﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Neremnem.AI;
public class DistanceService : BehaviorTree.Service
{
    //public DistanceService(SphereCollider collider)
    //{
    //    mBoundary = collider;
    //    mBoundary.isTrigger = true;
    //}
}